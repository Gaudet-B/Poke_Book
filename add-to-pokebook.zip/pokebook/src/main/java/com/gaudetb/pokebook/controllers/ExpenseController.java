package com.gaudetb.pokebook.controllers;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gaudetb.pokebook.models.Expense;
import com.gaudetb.pokebook.services.ExpenseService;

@RequestMapping("/expenses")
@Controller
public class ExpenseController {
	
	@Autowired
	ExpenseService expenseService;
	
	// ---------------------------
	// Constructors:
	
	
	// ---------------------------
	// Routes:
	
	@GetMapping("")
	public String index(@ModelAttribute("expense") Expense expense, Model model) {
		
		ArrayList<Expense> expenses = (ArrayList<Expense>) expenseService.findAll();
		model.addAttribute("expenses", expenses);
		
		return "index.jsp";
	}
	
	@PostMapping("/create")
	public String newExpense(@Valid @ModelAttribute("expense") Expense expense, BindingResult result, Model model) {
		if (result.hasErrors()) {
			
			ArrayList<Expense> expenses = (ArrayList<Expense>) expenseService.findAll();
			model.addAttribute("expenses", expenses);
			
			return "index.jsp";
		} else {
			expenseService.save(expense);
			return "redirect:/expenses";
		}
	}


}
